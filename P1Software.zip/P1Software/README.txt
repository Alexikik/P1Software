
# Hvad er programmet:
Dette er et program som søger efter ting i en database afhængigt af hvilken genbrugstype du er. Derfra kommer navnet genbrugsmatcher. Programmets funktion ligger i at søge efter specifikke ting fra en liste konfigureret til den givne genbrugstype. Her kan brugeren selv bestemme eventuelle filtre. Hvis brugeren ønsker at tilgå et produkt, bliver der yderligere mulighed for at 3) 'købe produktet', 2) 'besøg produkt siden' eller 1) 'returnere til listen'.


# Hvordan bruger man programmet?
Dette program er designet til windows, og virker derfor muligvis ikke på andre styresystemer.
Det kan compiles med: gcc GenbrugssammenlignerML1,00.c sqlite3.c